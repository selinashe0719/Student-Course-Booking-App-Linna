package com.example.bean;

import java.io.Serializable;

public class Course implements Serializable {
    private String cid;
    private int uid;
    private String name;// course name
    private String ban;// target course name
    private String num;// amount of student
    private String time;// course hour
    private String renshu;// student had register
    private String xz_time;// course time
    private Users user;




    public String getXz_time() {
        return xz_time;
    }

    public void setXz_time(String xz_time) {
        this.xz_time = xz_time;
    }

    public Users getUser() {
        return user;
    }

    public void setUser(Users user) {
        this.user = user;
    }


    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBan() {
        return ban;
    }

    public void setBan(String ban) {
        this.ban = ban;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getRenshu() {
        return renshu;
    }

    public void setRenshu(String renshu) {
        this.renshu = renshu;
    }

    public Course() {
        super();
        // TODO Auto-generated constructor stub
    }

    public Course(int uid, String name, String ban, String num,
                  String time) {
        super();
        this.uid = uid;
        this.name = name;
        this.ban = ban;
        this.num = num;
        this.time = time;
    }

}
