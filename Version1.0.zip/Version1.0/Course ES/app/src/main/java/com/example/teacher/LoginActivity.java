package com.example.teacher;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bean.Users;
import com.example.db.UserDBService;
import com.example.util.S;
import com.example.util.T;

/**
 * loginui
 *
 * @author Administrator
 */
public class LoginActivity extends AppCompatActivity implements OnClickListener {
    EditText et_user;
    EditText et_password;
    TextView tv_regster;
    TextView tv_login;
    String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        type = getIntent().getStringExtra("type");
        // initialize
        et_user = (EditText) findViewById(R.id.edit_denglu_user);
        et_password = (EditText) findViewById(R.id.edit_denglu_pwd);
        tv_login = (TextView) findViewById(R.id.tv_denglu_btn);
        tv_regster = (TextView) findViewById(R.id.tv_denglu_zhuce);
        tv_login.setOnClickListener(this);
        tv_regster.setOnClickListener(this);



        if (type.equals("3")) {
            tv_regster.setVisibility(View.GONE);
        }

    }

    /**
     * listener
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_denglu_btn:

                String str_user = et_user.getText().toString();
                String str_password = et_password.getText().toString();
                login(str_user, str_password);

                break;
            case R.id.tv_denglu_zhuce:// listener register bottom
                startActivity(new Intent(this, RegsterActivity.class));
                break;

        }

    }

    void login(String username, String pswd) {
        if (username == null || pswd == null || username.equals("")
                || pswd.equals("")) { //if empty
            T.Show("The user name or password cannot be empty!");

            return;
        }
        Users u = UserDBService.getInstence().search(username, pswd, type);
        if (u == null) {
            T.Show("Incorrect user name or password!");
        } else {
            S.setBoolean(LoginActivity.this, "login", "login", true);//save status,anti-login next time
            S.saveU(u);//save login status
            if (u.getType() == 1) {//jump in student main menu

            } else if (u.getType() == 2) {//jump in instructor main menu

            } else if (u.getType() == 3) {//jump in administrator main menu
                startActivity(new Intent(LoginActivity.this, AdminMainActivity.class));
            }

            finish();//break
        }

    }

    long newTime;

    /**
     * listener
     */
    @Override
    public void onBackPressed() {

        if (System.currentTimeMillis() - newTime > 2000) {
            newTime = System.currentTimeMillis();
            Toast.makeText(this, "Press the return key again to exit the program!", Toast.LENGTH_SHORT).show();
        } else {
            finish();
        }
    }

}
