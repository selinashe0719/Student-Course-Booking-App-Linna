package com.example.bean;

public class Users {
    int uid; // user id
    String user; // user name
    String pswd; // user password
    String sex; // gender（male female）
    String name; // realname
    int type;//3 admin 2.instructor  1.student
    String ban; // class
    String ke;// major

    public Users() {
        super();
    }


    public Users(int uid, String user, String pswd, String sex, String name,
                 String ban, String ke, int type) {
        super();
        this.type = type;
        this.uid = uid;
        this.user = user;
        this.pswd = pswd;
        this.sex = sex;
        this.name = name;
        this.ban = ban;
        this.ke = ke;
    }


    public int getType() {
        return type;
    }


    public void setType(int type) {
        this.type = type;
    }


    public String getBan() {
        return ban;
    }

    public void setBan(String ban) {
        this.ban = ban;
    }

    public String getKe() {
        return ke;
    }

    public void setKe(String ke) {
        this.ke = ke;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPswd() {
        return pswd;
    }

    public void setPswd(String pswd) {
        this.pswd = pswd;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
