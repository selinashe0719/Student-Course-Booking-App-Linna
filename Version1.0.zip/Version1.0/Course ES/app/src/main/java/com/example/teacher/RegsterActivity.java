package com.example.teacher;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bean.Users;
import com.example.db.UserDBService;
import com.example.util.T;

/**
 * register page
 *
 * @author Administrator
 */
public class RegsterActivity extends AppCompatActivity implements OnClickListener {
    EditText et_user;
    EditText et_pswd;

    EditText et_name, etBan;
    RadioGroup rg, rg2;
    TextView tv_regster;
    LinearLayout ll_back;
    String sex = "male";
    int type = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regster);

        et_user = (EditText) findViewById(R.id.regster_editText_user);
        et_pswd = (EditText) findViewById(R.id.regster_editText_password);

        et_name = (EditText) findViewById(R.id.regster_editText_name);
        etBan = (EditText) findViewById(R.id.etBan);
        rg2 = (RadioGroup) findViewById(R.id.rg);
        rg = (RadioGroup) findViewById(R.id.radioGroup1);
        tv_regster = (TextView) findViewById(R.id.regster_text_xiayibu);
        ll_back = (LinearLayout) findViewById(R.id.regster_layout_back);
        tv_regster.setOnClickListener(this);
        ll_back.setOnClickListener(this);
        rg.setOnCheckedChangeListener(new OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio_man) {
                    sex = "male";
                } else if (checkedId == R.id.radio_woman) {
                    sex = "female";
                }

            }
        });
        rg2.setOnCheckedChangeListener(new OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb1) {
                    type = 1;
                    etBan.setHint("Please input your major");
                } else if (checkedId == R.id.rb2) {
                    type = 2;
                    etBan.setHint("Please enter your teaching major");
                }

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.regster_layout_back:
                finish();
                break;
            case R.id.regster_text_xiayibu:
                String user = et_user.getText().toString();
                String pswd = et_pswd.getText().toString();
                String name = et_name.getText().toString();
                String ban = etBan.getText().toString();

                if (ban.equals("") || user.equals("") || pswd.equals("") || name.equals("")) {
                    T.Show("The content filled in cannot be blank!");
                    return;
                }
                Users u;
                if (UserDBService.getInstence().isExit(user)) {
                    T.Show("Account number already exists!");
                } else {
                    if (type == 1) {//student
                        UserDBService.getInstence().save(user, pswd, sex, name, ban, "", type);
                    } else {
                        UserDBService.getInstence().save(user, pswd, sex, name, "", ban, type);
                    }
                    T.Show("login was successful!");
                    finish();
                }


                break;

        }
    }

}
