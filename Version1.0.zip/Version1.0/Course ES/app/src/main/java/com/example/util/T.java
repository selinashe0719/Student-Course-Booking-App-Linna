package com.example.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Context;
import android.widget.Toast;
/**
 * reminder
 * @author Administrator
 *
 */
public class T {
	public static Context context;
	public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	/**
	 * show the reminder
	 */
	public static void Show(String content) {
		Toast.makeText(context, content, Toast.LENGTH_SHORT).show();
	}
	
	/**
	 * show the error remainder
	 */
	public static void ShowFail() {
		Toast.makeText(context, "failed to connect,please check if input IP correctly", Toast.LENGTH_SHORT).show();
	}
	
	public static String getTime(){
		return simpleDateFormat.format(new Date());
	}

}
