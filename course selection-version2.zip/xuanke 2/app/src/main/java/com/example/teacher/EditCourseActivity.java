package com.example.teacher;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bean.Course;
import com.example.bean.Users;
import com.example.db.CourseDBService;
import com.example.util.S;
import com.example.util.T;

/**
 * edit course
 *
 * @author Administrator
 */
public class EditCourseActivity extends AppCompatActivity {

    Users teacher;
    EditText etName, etCid;
    TextView tv_fb;
    String name = "";
    Course course;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_course);
        course = (Course) getIntent().getSerializableExtra("course");
        teacher = S.loadU();
        findViewById(R.id.layout_back).setOnClickListener(
                new OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        finish();

                    }
                });

        tv_fb = (TextView) findViewById(R.id.tv_fabiao_btn);
        tv_fb.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                String cid = etCid.getText().toString();

                name = etName.getText().toString();
                if (cid.equals("") || name.equals("")) {
                    T.Show("The content filled in cannot be blank");
                    return;
                }
                if (CourseDBService.getInstence().isExit(cid)&&!cid.equals(course.getCid())) {
                    T.Show("Course number already exists");
                    return;
                }

                course.setName(name);
                course.setCid(cid);
                CourseDBService.getInstence().update2(course);
                T.Show("Edit successfully");
                finish();


            }
        });

        etName = (EditText) findViewById(R.id.etName);
        etCid = (EditText) findViewById(R.id.etCid);
        etName.setText(course.getName());
        etCid.setText(course.getCid());


    }

}
