package com.example.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.bean.Jiaru;
import com.example.bean.Course;
import com.example.util.T;
import com.example.util.TimeUtil;

import java.util.ArrayList;


/**
 * data base
 *
 * @author Administrator
 */
public class CourseDBService {

    public class SpDBHelper extends SQLiteOpenHelper {

        public final String TABLE_NAME = "course"; //表名


        public SpDBHelper(Context context) {
            super(context, "mydb", null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("create table " + TABLE_NAME + " (cid varchar(100) primary key,uid integer,name text,ban text,num text,time text,sh_time text,xz_time text)");
            db.execSQL("create table jiaru (jid integer primary key autoincrement,uid integer,cid varchar(100),tid integer,score integer)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    }

    private static CourseDBService mInstence;
    private SpDBHelper helper;
    private String TABLE_NAME;


    /**
     * if course number been used
     *
     * @param
     * @return
     */
    public boolean isExit(String cid) {
        Cursor cursor = helper.getReadableDatabase().query(TABLE_NAME, null, "cid = ?", new String[]{cid}, null,
                null, null, null);
        while (cursor.moveToNext()) {
            return true;

        }
        return false;
    }


    public ArrayList<Course> searchAllCouse(String keyWord) {
        ArrayList<Course> list = new ArrayList<>();
        Cursor cursor;
        if (keyWord.equals("")) {
            cursor = helper.getReadableDatabase().query(TABLE_NAME, null, null, null, null,
                    null, null, null);
        } else {
            cursor = helper.getReadableDatabase().query(TABLE_NAME, null, "cid like ?", new String[]{"%" + keyWord + "%"}, null,
                    null, null, null);
        }
        while (cursor.moveToNext()) {
            Course object = new Course();
            object.setCid(cursor.getString(cursor.getColumnIndex("cid")));
            object.setUid(cursor.getInt(cursor.getColumnIndex("uid")));
            object.setName(cursor.getString(cursor.getColumnIndex("name")));
            object.setBan(cursor.getString(cursor.getColumnIndex("ban")));
            object.setNum(cursor.getString(cursor.getColumnIndex("num")));
            object.setTime(cursor.getString(cursor.getColumnIndex("time")));
            object.setXz_time(cursor.getString(cursor.getColumnIndex("xz_time")));
            list.add(object);


        }
        return list;
    }

    public ArrayList<Course> searchAllCouse(String keyWord, int uid) {
        ArrayList<Course> list = new ArrayList<>();
        Cursor cursor;
        if (keyWord.equals("")) {
            cursor = helper.getReadableDatabase().query(TABLE_NAME, null, "uid = ?", new String[]{"" + uid}, null,
                    null, null, null);
        } else {
            cursor = helper.getReadableDatabase().query(TABLE_NAME, null, "cid like ? and uid = ?", new String[]{"%" + keyWord + "%", "" + uid}, null,
                    null, null, null);
        }
        while (cursor.moveToNext()) {
            Course object = new Course();
            object.setCid(cursor.getString(cursor.getColumnIndex("cid")));
            object.setUid(cursor.getInt(cursor.getColumnIndex("uid")));
            object.setName(cursor.getString(cursor.getColumnIndex("name")));
            object.setBan(cursor.getString(cursor.getColumnIndex("ban")));
            object.setNum(cursor.getString(cursor.getColumnIndex("num")));
            object.setTime(cursor.getString(cursor.getColumnIndex("time")));
            object.setXz_time(cursor.getString(cursor.getColumnIndex("xz_time")));
            list.add(object);


        }
        return list;
    }

    public Course searchByCid(String cid) {
        Cursor cursor = helper.getReadableDatabase().query(TABLE_NAME, null, "cid = ?", new String[]{cid + ""}, null,
                null, null, null);
        if (cursor.moveToNext()) {
            Course object = new Course();
            object.setCid(cursor.getString(cursor.getColumnIndex("cid")));
            object.setUid(cursor.getInt(cursor.getColumnIndex("uid")));
            object.setName(cursor.getString(cursor.getColumnIndex("name")));
            object.setBan(cursor.getString(cursor.getColumnIndex("ban")));
            object.setNum(cursor.getString(cursor.getColumnIndex("num")));
            object.setTime(cursor.getString(cursor.getColumnIndex("time")));
            object.setXz_time(cursor.getString(cursor.getColumnIndex("xz_time")));
            return object;


        }
        return null;
    }

    public ArrayList<Course> searchAll(String keyWord) {
        ArrayList<Course> list = new ArrayList<>();

        Cursor cursor;
        if (keyWord.equals("")) {
            cursor = helper.getReadableDatabase().query(TABLE_NAME, null, null, null, null,
                    null, null, null);
        } else {
            cursor = helper.getReadableDatabase().query(TABLE_NAME, null, "cid like ? or name like ? or xz_time like ?", new String[]{"%" + keyWord + "%", "%" + keyWord + "%", "%" + keyWord + "%"}, null,
                    null, null, null);
        }

        while (cursor.moveToNext()) {
            Course object = new Course();
            object.setCid(cursor.getString(cursor.getColumnIndex("cid")));
            object.setUid(cursor.getInt(cursor.getColumnIndex("uid")));
            object.setName(cursor.getString(cursor.getColumnIndex("name")));
            object.setBan(cursor.getString(cursor.getColumnIndex("ban")));
            object.setNum(cursor.getString(cursor.getColumnIndex("num")));
            object.setTime(cursor.getString(cursor.getColumnIndex("time")));
            object.setXz_time(cursor.getString(cursor.getColumnIndex("xz_time")));
            if (object.getUid() != -1) {
                list.add(object);
            }


        }
        return list;
    }


    public int searchNum(String cid) {
        Cursor cursor = helper.getReadableDatabase().query("jiaru", null, "cid = ?", new String[]{cid + ""}, null,
                null, null, null);
        int count = 0;
        while (cursor.moveToNext()) {
            count++;


        }
        return count;
    }


    /**
     * load
     */
    public boolean update(Course object) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", object.getName());
        contentValues.put("uid", object.getUid());
        contentValues.put("ban", object.getBan());
        contentValues.put("time", object.getTime());
        contentValues.put("num", object.getNum());
        contentValues.put("xz_time", object.getXz_time());
        contentValues.put("sh_time", TimeUtil.getDate());


        long result = helper.getWritableDatabase().update(TABLE_NAME, contentValues, "cid = ?", new String[]{object.getCid()});

        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean update2(Course object) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", object.getName());
        contentValues.put("cid", object.getCid());


        long result = helper.getWritableDatabase().update(TABLE_NAME, contentValues, "cid = ?", new String[]{object.getCid()});

        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean save(String name, String cid) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("cid", cid);
        contentValues.put("uid", -1);


        long result = helper.getWritableDatabase().insert(TABLE_NAME, null, contentValues);
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }


    /**
     * if been added
     *
     * @param
     * @return
     */
    public boolean isExit(int uid, String cid) {
        Cursor cursor = helper.getReadableDatabase().query("jiaru", null, "uid = ? and cid = ?", new String[]{uid + "", cid + ""}, null,
                null, null, null);
        while (cursor.moveToNext()) {
            return true;

        }
        return false;
    }

    /**
     * load
     */
    public boolean save(Jiaru object) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("uid", object.getUid());
        contentValues.put("cid", object.getCid());
        contentValues.put("tid", object.getTid());
        contentValues.put("score", 0);


        long result = helper.getWritableDatabase().insert("jiaru", null, contentValues);
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }


    public ArrayList<Jiaru> searchJRByUid(int uid) {
        ArrayList<Jiaru> list = new ArrayList<>();
        Cursor cursor = helper.getReadableDatabase().query("jiaru", null, "uid = ?", new String[]{uid + ""}, null,
                null, null, null);
        while (cursor.moveToNext()) {
            Jiaru object = new Jiaru();
            object.setCid(cursor.getString(cursor.getColumnIndex("cid")));
            object.setUid(cursor.getInt(cursor.getColumnIndex("uid")));
            object.setJid(cursor.getInt(cursor.getColumnIndex("jid")));
            object.setTid(cursor.getInt(cursor.getColumnIndex("tid")));

            list.add(object);


        }
        return list;
    }

    public ArrayList<Jiaru> searchJRByCid(String id) {
        ArrayList<Jiaru> list = new ArrayList<>();
        Cursor cursor = helper.getReadableDatabase().query("jiaru", null, "cid = ?", new String[]{id + ""}, null,
                null, null, null);
        while (cursor.moveToNext()) {
            Jiaru object = new Jiaru();
            object.setCid(cursor.getString(cursor.getColumnIndex("cid")));
            object.setUid(cursor.getInt(cursor.getColumnIndex("uid")));
            object.setJid(cursor.getInt(cursor.getColumnIndex("jid")));
            object.setTid(cursor.getInt(cursor.getColumnIndex("tid")));

            list.add(object);


        }
        return list;
    }


    /**
     * delete by id
     *
     * @param
     * @return
     */
    public boolean delete(String cid) {
        long result = helper.getWritableDatabase().delete(TABLE_NAME, "cid = ?", new String[]{cid + ""});
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteJRForPid(String cid) {
        long result = helper.getWritableDatabase().delete("jiaru", "cid = ?", new String[]{cid + ""});
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean deleteJR(int jid) {
        long result = helper.getWritableDatabase().delete("jiaru", "jid = ?", new String[]{jid + ""});
        if (result > 0) {
            return true;
        } else {
            return false;
        }
    }


    public static CourseDBService getInstence() {
        if (mInstence == null) {
            synchronized (CourseDBService.class) {
                if (mInstence == null) {
                    mInstence = new CourseDBService(T.context);
                }
            }
        }
        return mInstence;
    }

    public CourseDBService(Context context) {
        close();
        helper = new SpDBHelper(context);
        TABLE_NAME = helper.TABLE_NAME;
    }

    private synchronized void close() {
        if (helper != null) {
            helper.close();
            helper = null;
        }
    }

}
