package com.example.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class TimeUtil {

	public static String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String time = sdf.format(new Date());
		return time;
	}
	public static String getDates() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String time = sdf.format(new Date());
		return time;
	}

	public static boolean is(String t2) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String t1 = sdf.format(new Date());
		try {

			Date d1 = sdf.parse(t1);
			long l1 = d1.getTime();

			Date d2 = sdf.parse(t2);
			long l2 = d2.getTime();

			if (l2 >= l1) {
				return true;
			} else {
				return false;
			}

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * 
	 * @param t1
	 * @param t2
	 * @return
	 */
	public static long getSYTime(String t1,String t2) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String t3 = sdf.format(new Date());
		try {
			
			Date d1 = sdf.parse(t1);
			long l1 = d1.getTime()+Integer.parseInt(t2)*24*60*60*1000;
			
			Date d3 = sdf.parse(t3);
			long l3 = d3.getTime();
			
			return l1-l3;
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
}
