package com.example.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.bean.Users;
import com.google.gson.Gson;

/**
 * load
 */
public class S {
	public static Context context;

	public static void setBoolean(Context context, String type, String key,
			boolean value) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putBoolean(key, value).commit();

	}

	public static boolean getBoolean(Context context, String type, String key) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		return preferences.getBoolean(key, false);
	}

	public static boolean getBoolean(Context context, String type, String key,
			boolean defaults) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		return preferences.getBoolean(key, defaults);
	}

	public static void setString(Context context, String type, String key,
			String value) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putString(key, value).commit();

	}

	public static String getString(Context context, String type, String key) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		return preferences.getString(key, "admin");

	}

	public static String getString(Context context, String type, String key,
			String def) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		return preferences.getString(key, def);

	}

	public static void setInt(Context context, String type, String key,
			int value) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putInt(key, value).commit();

	}

	public static int getInt(Context context, String type, String key) {
		SharedPreferences preferences = context.getSharedPreferences(type,
				context.MODE_PRIVATE);
		return preferences.getInt(key, 0);

	}

	public static boolean isAdmin(Context context) {
		SharedPreferences preferences = context.getSharedPreferences("isAdmin",
				context.MODE_PRIVATE);
		return preferences.getBoolean("isAdmin", false);

	}

	public static void saveU(Users u) {
		SharedPreferences preferences = context.getSharedPreferences("user",
				context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putString("user", new Gson().toJson(u)).commit();

	}

	public static Users loadU() {
		SharedPreferences preferences = context.getSharedPreferences("user",
				context.MODE_PRIVATE);
		String json = preferences.getString("user", "");
		return new Gson().fromJson(json, Users.class);

	}

	public static boolean isAdmin() {
		SharedPreferences preferences = T.context.getSharedPreferences(
				"isAdmin", T.context.MODE_PRIVATE);
		return preferences.getBoolean("isAdmin", false);

	}

	public static void save_isAdmin(boolean isAdmin) {
		SharedPreferences preferences = T.context.getSharedPreferences(
				"isAdmin", T.context.MODE_PRIVATE);
		SharedPreferences.Editor editor = preferences.edit();
		editor.putBoolean("isAdmin", isAdmin).commit();

	}

}
