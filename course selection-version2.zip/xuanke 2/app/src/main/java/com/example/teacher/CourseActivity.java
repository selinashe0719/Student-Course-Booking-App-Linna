package com.example.teacher;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.bean.Course;
import com.example.db.CourseDBService;
import com.example.db.UserDBService;
import com.example.util.S;
import com.example.util.T;

import java.util.ArrayList;

/**
 * course list
 *
 * @author Administrator
 */
public class CourseActivity extends FragmentActivity {
    ListView lv;

    ArrayList<Course> plist;
    MyAdapter adapter;
    int uid;
    EditText etSearch;
    String keyWord = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_course);
        lv = (ListView) findViewById(R.id.lv);
        etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                keyWord = editable.toString();
                getData();
            }
        });
        findViewById(R.id.ivBack).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();

            }
        });
        if (S.loadU().getType() != 3) {
            findViewById(R.id.ivAdd).setVisibility(View.GONE);
        }
        findViewById(R.id.ivAdd).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(CourseActivity.this, AddCourseActivity.class));

            }
        });
        uid = S.loadU().getUid();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    final int position, long id) {
                final Course p = plist.get(position);
                if (S.loadU().getType() == 3) {
                    new AlertDialog.Builder(CourseActivity.this)
                            .setTitle("operation")
                            .setItems(new String[]{"Edit course","Delete course"},
                                    new DialogInterface.OnClickListener() {

                                        @Override
                                        public void onClick(
                                                DialogInterface arg0, int arg1) {
                                            switch (arg1) {
                                                case 0:
                                                    startActivity(new Intent(CourseActivity.this, EditCourseActivity.class).putExtra("course", p));
                                                    break;

                                                case 1:

                                                    CourseDBService.getInstence().delete(p.getCid());
                                                    CourseDBService.getInstence().deleteJRForPid(p.getCid());
                                                    getData();
                                                    T.Show("Successfully deleted");

                                                    break;

                                            }

                                        }
                                    }).setNegativeButton("Cancel", null).show();
                } else if (S.loadU().getType() == 2) {
                    if (p.getUid() != -1) {

                        if (p.getUid() == S.loadU().getUid()) {
                            new AlertDialog.Builder(CourseActivity.this)
                                    .setTitle("operation")
                                    .setItems(new String[]{"View selected students", "Delete course"},
                                            new DialogInterface.OnClickListener() {

                                                @Override
                                                public void onClick(
                                                        DialogInterface arg0, int arg1) {
                                                    switch (arg1) {

                                                        case 0:
                                                            startActivity(new Intent(CourseActivity.this, XuanKeStudentActivity.class).putExtra("cid", plist.get(position).getCid()));
                                                            break;
                                                        case 1:
                                                            p.setUid(-1);
                                                            CourseDBService.getInstence().update(p);
                                                            getData();
                                                            T.Show("Operation successful");

                                                            break;

                                                    }

                                                }
                                            }).setNegativeButton("Cancel", null).show();
                        } else {
                            T.Show("Selected by other teachers");
                        }


                    } else {


                        new AlertDialog.Builder(CourseActivity.this).setTitle("Select").setMessage("Do you want to teach this course？").setPositiveButton("Sure", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {


                                startActivity(new Intent(CourseActivity.this, SelectCourseActivity.class).putExtra("course", plist.get(position)));


                            }
                        }).setNegativeButton("Cancel", null).show();


                    }


                } else {

                }


            }
        });
    }

    @Override
    public void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        getData();

    }

    private void getData() {
        plist = new ArrayList<>();
        ArrayList<Course> list = CourseDBService.getInstence().searchAllCouse(keyWord);
        for (int i = 0; i < list.size(); i++) {
            Course pic = list.get(i);
            if (pic.getUid() != -1) {
                pic.setUser(UserDBService.getInstence().search(pic.getUid()));
            }
            pic.setRenshu(CourseDBService.getInstence().searchNum(pic.getCid()) + "");
            plist.add(pic);
        }
        if (adapter == null) {
            adapter = new MyAdapter();
            lv.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();

        }

    }


    class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return plist.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return plist.get(position);
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Holder holder = null;
            if (convertView == null) {
                holder = new Holder();
                convertView = LayoutInflater.from(CourseActivity.this).inflate(
                        R.layout.item1, null);
                holder.tv_title = (TextView) convertView
                        .findViewById(R.id.tv_title);
                holder.tv_time = (TextView) convertView
                        .findViewById(R.id.tv_time);
                convertView.setTag(holder);
            } else {
                holder = (Holder) convertView.getTag();
            }
            if (plist.get(position).getUid() == -1) {

                holder.tv_time.setText("Course number：" + plist.get(position).getCid());

            } else {

                holder.tv_time.setText(
                        "Course number：" + plist.get(position).getCid()
                                + "\nclass hours：" + plist.get(position).getTime()
                                + "\nTotal attendance：" + plist.get(position).getNum() + "people"
                                + "\nNumber of selected courses：" + plist.get(position).getRenshu() + "people"
                                + "\nClass time：" + plist.get(position).getXz_time()
                                + "\n\nCourse introduction：" + plist.get(position).getBan()

                );

            }


            holder.tv_title.setText("Course name：" + plist.get(position).getName());

            return convertView;
        }

    }

    class Holder {
        TextView tv_title, tv_time;
    }

}
