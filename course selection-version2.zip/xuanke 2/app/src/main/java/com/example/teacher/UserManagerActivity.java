package com.example.teacher;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.bean.Users;
import com.example.db.UserDBService;
import com.example.util.T;
import com.example.util.TimeUtil;

import org.json.JSONArray;

import java.util.ArrayList;

/**
 * user management profil
 */
public class UserManagerActivity extends AppCompatActivity {
    TextView tv1, tv2;
    ListView lv;
    int type = 1;
    ArrayList<Users> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_manager);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        lv = findViewById(R.id.lv);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int pos, long l) {
                new AlertDialog.Builder(UserManagerActivity.this).setTitle("Delete").setMessage("Do you want to delete this account？").setPositiveButton("Sure", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        UserDBService.getInstence().delete(list.get(pos).getUid());
                        T.Show("Successfully deleted！");
                        getData();


                    }
                }).setNegativeButton("Cancel", null).show();
            }
        });


        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type = 1;
                tv1.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                tv1.setTextColor(Color.WHITE);
                tv2.setBackgroundColor(Color.WHITE);
                tv2.setTextColor(Color.BLACK);
                getData();
            }
        });
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                type = 2;
                tv2.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                tv2.setTextColor(Color.WHITE);
                tv1.setBackgroundColor(Color.WHITE);
                tv1.setTextColor(Color.BLACK);
                getData();
            }
        });
        findViewById(R.id.layout_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        getData();
    }

    void getData() {
        list = UserDBService.getInstence().searchForType(type);
        lv.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return list.size();
            }

            @Override
            public Object getItem(int i) {
                return list.get(i);
            }

            @Override
            public long getItemId(int i) {
                return i;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup viewGroup) {


                Holder holder = null;
                if (convertView == null) {
                    holder = new Holder();
                    convertView = LayoutInflater.from(UserManagerActivity.this).inflate(
                            R.layout.item1, null);
                    holder.tv_title = (TextView) convertView
                            .findViewById(R.id.tv_title);
                    holder.tv_time = (TextView) convertView
                            .findViewById(R.id.tv_time);
                    convertView.setTag(holder);
                } else {
                    holder = (Holder) convertView.getTag();
                }
                if (list.get(position).getType() == 1) {

                    holder.tv_time.setText(
                            "Sex：" + list.get(position).getSex()
                                    + "\nProfessional：" + list.get(position).getBan()
                    );

                } else {
                    holder.tv_time.setText(
                            "Sex：" + list.get(position).getSex()
                                    + "\nSubject：" + list.get(position).getKe()
                    );
                }


                holder.tv_title.setText("Name：" + list.get(position).getName());

                return convertView;
            }


        });
    }

    class Holder {
        TextView tv_title, tv_time;
    }
}