package com.example.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Context;
import android.widget.Toast;
/**
 * hint
 * @author Administrator
 *
 */
public class T {
	public static Context context;
	public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	/**
	 * show hint
	 */
	public static void Show(String content) {
		Toast.makeText(context, content, Toast.LENGTH_SHORT).show();
	}
	
	/**
	 * hint massage
	 */
	public static void ShowFail() {
		Toast.makeText(context, "error，please check you IP", Toast.LENGTH_SHORT).show();
	}
	
	public static String getTime(){
		return simpleDateFormat.format(new Date());
	}

}
