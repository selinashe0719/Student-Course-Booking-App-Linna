package com.example.teacher;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bean.Jiaru;
import com.example.bean.Course;
import com.example.bean.Users;
import com.example.db.CourseDBService;
import com.example.db.UserDBService;
import com.example.util.T;

import java.util.ArrayList;

//student had register
public class XuanKeStudentActivity extends AppCompatActivity {
    ListView lv;
    ArrayList<Jiaru> list;
    String cid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_list);
        cid = getIntent().getStringExtra("cid");
        lv = (ListView) findViewById(R.id.lv);

        findViewById(R.id.ivBack).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();

            }
        });


    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        getList();
    }

    /**
     * get studentinfo
     */
    private void getList() {

        list = new ArrayList<>();
        ArrayList<Jiaru> listS = CourseDBService.getInstence().searchJRByCid(cid);
        for (int i = 0; i < listS.size(); i++) {
            Jiaru jiaru = listS.get(i);
            Users users = UserDBService.getInstence().search(jiaru.getUid());
            Course pic = CourseDBService.getInstence().searchByCid(jiaru.getCid());
            jiaru.setU(users);
            jiaru.setP(pic);
            list.add(i, jiaru);
        }


        lv.setAdapter(new BaseAdapter() {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView tView = new TextView(XuanKeStudentActivity.this);
                tView.setText("Name：" + list.get(position).getU().getName()
                        + "\nSex：" + list.get(position).getU().getSex()
                        + "\nProfessional class：" + list.get(position).getU().getBan()

                );
                tView.setPadding(20, 20, 20, 20);
                return tView;
            }

            @Override
            public long getItemId(int position) {
                // TODO Auto-generated method stub
                return position;
            }

            @Override
            public Object getItem(int position) {
                // TODO Auto-generated method stub
                return list.get(position);
            }

            @Override
            public int getCount() {
                // TODO Auto-generated method stub
                return list.size();
            }
        });

    }

}
