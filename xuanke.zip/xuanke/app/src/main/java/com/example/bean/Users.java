package com.example.bean;

import java.io.Serializable;

public class Users implements Serializable {
    int uid; // 用户id
    String user; // 用户名
    String pswd; // 密码
    String sex; // 性别（male female）
    String name; // 名字
    int type;//3 管理员 2.老师  1学生
    String ban; // 专业班级
    String ke;// 学科

    public Users() {
        super();
    }


    public Users(int uid, String user, String pswd, String sex, String name,
                 String ban, String ke, int type) {
        super();
        this.type = type;
        this.uid = uid;
        this.user = user;
        this.pswd = pswd;
        this.sex = sex;
        this.name = name;
        this.ban = ban;
        this.ke = ke;
    }


    public int getType() {
        return type;
    }


    public void setType(int type) {
        this.type = type;
    }


    public String getBan() {
        return ban;
    }

    public void setBan(String ban) {
        this.ban = ban;
    }

    public String getKe() {
        return ke;
    }

    public void setKe(String ke) {
        this.ke = ke;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPswd() {
        return pswd;
    }

    public void setPswd(String pswd) {
        this.pswd = pswd;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
