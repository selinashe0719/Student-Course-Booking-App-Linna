package com.example.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Context;
import android.widget.Toast;
/**
 * 提示各种请求结果工具类
 * @author Administrator
 *
 */
public class T {
	public static Context context;
	public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	/**
	 * 显示提示消息
	 */
	public static void Show(String content) {
		Toast.makeText(context, content, Toast.LENGTH_SHORT).show();
	}
	
	/**
	 * 显示提示消息
	 */
	public static void ShowFail() {
		Toast.makeText(context, "没有连接上服务器，请查看ip地址是否设置对应", Toast.LENGTH_SHORT).show();
	}
	
	public static String getTime(){
		return simpleDateFormat.format(new Date());
	}

}
