package com.example.teacher;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bean.Course;
import com.example.bean.Users;
import com.example.db.CourseDBService;
import com.example.util.S;
import com.example.util.T;

/**
 * 老师编辑课程界面
 *
 * @author Administrator
 */
public class EditCourseForTeacherActivity extends AppCompatActivity {

    Users teacher;
    EditText etName,etCid, etBan, etNum, etTime, etXZTime;
    TextView tv_fb,tvTitle;
    String name = "";
    Course course;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_course);
        course = (Course) getIntent().getSerializableExtra("course");
        teacher = S.loadU();
        findViewById(R.id.layout_back).setOnClickListener(
                new OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        finish();

                    }
                });

        tvTitle = (TextView) findViewById(R.id.tvTitle);
        tvTitle.setText("edit course");
        tv_fb = (TextView) findViewById(R.id.tv_fabiao_btn);
        tv_fb.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                String ban = etBan.getText().toString();
                String num = etNum.getText().toString();
                String time = etTime.getText().toString();
                String xztime = etXZTime.getText().toString();
                if (xztime.equals("") || ban.equals("") || num.equals("")
                        || time.equals("")) {
                    T.Show("The content filled in cannot be blank");
                    return;
                }


                course.setUid(teacher.getUid());
                course.setBan(ban);
                course.setNum(num);
                course.setTime(time);
                course.setXz_time(xztime);
                CourseDBService.getInstence().update(course);
                T.Show("Operation successful");
                finish();


            }
        });
        tv_fb.setText("edit");

        etName = (EditText) findViewById(R.id.etName);
        etCid = (EditText) findViewById(R.id.etCid);
        etBan = (EditText) findViewById(R.id.etBan);
        etNum = (EditText) findViewById(R.id.etNum);
        etTime = (EditText) findViewById(R.id.etTime);
        etXZTime = (EditText) findViewById(R.id.etXZTime);

        etName.setText(course.getName());
        etCid.setText(course.getCid());
        etBan.setText(course.getBan());
        etNum.setText(course.getNum());
        etTime.setText(course.getTime());
        etXZTime.setText(course.getXz_time());

    }

}
