package com.example.teacher;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.FragmentActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.bean.Jiaru;
import com.example.bean.Course;
import com.example.bean.Users;
import com.example.db.CourseDBService;
import com.example.db.UserDBService;
import com.example.util.S;
import com.example.util.T;
import com.example.util.TimeUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * 选课界面列表
 *
 * @author Administrator
 */
public class XuanKeActivity extends FragmentActivity {
    ListView lv;

    List<Course> list;
    MyAdapter adapter;
    EditText etSearch;
    String keyWord = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_xuanke);

        etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                keyWord = editable.toString();
                getData();
            }
        });

        lv = (ListView) findViewById(R.id.lv);
        lv.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1,
                                    final int arg2, long arg3) {
                new AlertDialog.Builder(XuanKeActivity.this)
                        .setTitle("operation")
                        .setItems(new String[]{"Take this course", "Cancel"},
                                new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface arg0,
                                                        int arg1) {
                                        switch (arg1) {

                                            case 0:


                                                if (Integer.parseInt(list.get(arg2).getNum()) > Integer.parseInt(list.get(arg2).getRenshu())) {
                                                    Jiaru jiaru = new Jiaru(-1, S.loadU()
                                                            .getUid(), list.get(arg2)
                                                            .getCid(), list.get(arg2)
                                                            .getUid());
                                                    if (CourseDBService.getInstence().isExit(jiaru.getUid(), jiaru.getCid())) {
                                                        T.Show("You have already joined this course. You cannot join it again");
                                                    } else {
                                                        CourseDBService.getInstence().save(jiaru);
                                                        T.Show("Join successfully");
                                                        getData();
                                                    }

                                                } else {
                                                    T.Show("The number of people is full");
                                                }


                                                break;

                                        }

                                    }
                                }).show();

            }
        });
        findViewById(R.id.ivBack).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();

            }
        });


        getData();

    }

    private void getData() {
        list = new ArrayList<>();
        ArrayList<Course> listS = CourseDBService.getInstence().searchAll(keyWord);
        for (int i = 0; i < listS.size(); i++) {
            Course pic = listS.get(i);
            Users users = UserDBService.getInstence().search(pic.getUid());
            pic.setRenshu(CourseDBService.getInstence().searchNum(pic.getCid()) + "");
            pic.setUser(users);
            list.add(i, pic);
        }
        if (adapter == null) {
            adapter = new MyAdapter();
            lv.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();

        }

    }

    class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return list.size();
        }

        @Override
        public Object getItem(int arg0) {
            // TODO Auto-generated method stub
            return list.get(arg0);
        }

        @Override
        public long getItemId(int arg0) {
            // TODO Auto-generated method stub
            return arg0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup arg2) {

            Holder holder = null;
            if (convertView == null) {
                holder = new Holder();
                convertView = LayoutInflater.from(XuanKeActivity.this).inflate(
                        R.layout.item1, null);
                holder.tv_title = (TextView) convertView
                        .findViewById(R.id.tv_title);
                holder.tv_time = (TextView) convertView
                        .findViewById(R.id.tv_time);
                convertView.setTag(holder);
            } else {
                holder = (Holder) convertView.getTag();
            }

            holder.tv_time.setText(
                    "Course number：" + list.get(position).getCid()
                            + "\nclass hours：" + list.get(position).getTime()
                            + "\nTotal attendance：" + list.get(position).getNum() + "people"
                            + "\nNumber of selected courses：" + list.get(position).getRenshu() + "people"
                            + "\nClass time：" + list.get(position).getXz_time()
                            + "\n\nCourse introduction：" + list.get(position).getBan());




            holder.tv_title.setText("Course name：" + list.get(position).getName()
                    + "\nTeacher：" + list.get(position).getUser().getName());

            return convertView;

        }

    }

    class Holder {
        TextView tv_title, tv_time;
    }

}
