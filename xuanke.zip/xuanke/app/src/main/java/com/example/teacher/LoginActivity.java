package com.example.teacher;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bean.Users;
import com.example.db.UserDBService;
import com.example.util.S;
import com.example.util.T;

/**
 * 登录界面
 *
 * @author Administrator
 */
public class LoginActivity extends AppCompatActivity implements OnClickListener {
    EditText et_user;
    EditText et_password;
    TextView tv_regster;
    TextView tv_login;
    String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        type = getIntent().getStringExtra("type");
        // 初始化控件
        et_user = (EditText) findViewById(R.id.edit_denglu_user);
        et_password = (EditText) findViewById(R.id.edit_denglu_pwd);
        tv_login = (TextView) findViewById(R.id.tv_denglu_btn);
        tv_regster = (TextView) findViewById(R.id.tv_denglu_zhuce);
        tv_login.setOnClickListener(this);
        tv_regster.setOnClickListener(this);



        if (type.equals("3")) {
            tv_regster.setVisibility(View.GONE);
        }

    }

    /**
     * 监听各种按钮
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_denglu_btn:

                String str_user = et_user.getText().toString();
                String str_password = et_password.getText().toString();
                login(str_user, str_password);

                break;
            case R.id.tv_denglu_zhuce:// 监听注册按钮
                startActivity(new Intent(this, RegsterActivity.class));
                break;

        }

    }

    void login(String username, String pswd) {
        if (username == null || pswd == null || username.equals("")
                || pswd.equals("")) { //判断输入的账号和密码是否为空
            T.Show("The user name or password cannot be empty!");

            return;
        }
        Users u = UserDBService.getInstence().search(username, pswd, type);
        if (u == null) {
            T.Show("Incorrect user name or password!");
        } else {
            S.setBoolean(LoginActivity.this, "login", "login", true);//缓存登录状态，下次自动登录
            S.saveU(u);//缓存用户登录信息
            if (u.getType() == 1) {//跳转学生主界面
                startActivity(new Intent(LoginActivity.this, StudentMainActivity.class));
            } else if (u.getType() == 2) {//跳转老师主界面
                startActivity(new Intent(LoginActivity.this, TeacherMainActivity.class));
            } else if (u.getType() == 3) {//跳转管理员主界面
                startActivity(new Intent(LoginActivity.this, AdminMainActivity.class));
            }

            finish();//销毁当前界面
        }

    }

    long newTime;

    /**
     * 监听返回键
     */
    @Override
    public void onBackPressed() {

        if (System.currentTimeMillis() - newTime > 2000) {
            newTime = System.currentTimeMillis();
            Toast.makeText(this, "Press the return key again to exit the program!", Toast.LENGTH_SHORT).show();
        } else {
            finish();
        }
    }

}
