package com.example.teacher;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bean.Jiaru;
import com.example.bean.Course;
import com.example.bean.Users;
import com.example.db.CourseDBService;
import com.example.db.UserDBService;
import com.example.util.S;
import com.example.util.T;

import java.util.ArrayList;

//学生申请的课程界面
public class StudentMyKechengActivity extends AppCompatActivity {
    ListView lv;
    ArrayList<Jiaru> list;
    int uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kecheng_list);
        uid = S.loadU().getUid();
        lv = (ListView) findViewById(R.id.lv);
        lv.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    final int position, long id) {
                new AlertDialog.Builder(StudentMyKechengActivity.this)
                        .setTitle("option")
                        .setItems(new String[]{"Withdraw", "Cancel"},
                                new DialogInterface.OnClickListener() {

                                    @Override
                                    public void onClick(DialogInterface dialog,
                                                        int which) {
                                        dialog.dismiss();
                                        switch (which) {
                                            case 0:
                                                CourseDBService.getInstence().deleteJR(list.get(position).getJid());
                                                T.Show("Successful withdrawal");
                                                getList();
                                                break;
                                        }

                                    }
                                }).show();

            }
        });
        findViewById(R.id.ivBack).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                finish();

            }
        });

    }

    @Override
    protected void onResume() {
        // TODO Auto-generated method stub
        super.onResume();
        getList();
    }

    /**
     * 获取已报名学生列表
     */
    private void getList() {

        list = new ArrayList<>();
        ArrayList<Jiaru> listS = CourseDBService.getInstence().searchJRByUid(S.loadU().getUid());
        for (int i = 0; i < listS.size(); i++) {
            Jiaru jiaru = listS.get(i);
            Users users = UserDBService.getInstence().search(jiaru.getTid());
            Course pic = CourseDBService.getInstence().searchByCid(jiaru.getCid());
            pic.setUser(users);
            jiaru.setP(pic);
            list.add(i, jiaru);
        }


        lv.setAdapter(new BaseAdapter() {

            @Override
            public View getView(int position, View convertView,
                                ViewGroup parent) {
                TextView tView = new TextView(
                        StudentMyKechengActivity.this);

                tView.setText("Course name："
                        + list.get(position).getP().getName()
                        + "\nTeacher："
                        + list.get(position).getP().getUser()
                        .getName()
                        + "\nclass hours："
                        + list.get(position).getP().getTime()
                        + "\nClass time：" + list.get(position).getP().getXz_time()


                );
                tView.setPadding(20, 20, 20, 20);
                return tView;
            }

            @Override
            public long getItemId(int position) {
                // TODO Auto-generated method stub
                return position;
            }

            @Override
            public Object getItem(int position) {
                // TODO Auto-generated method stub
                return list.get(position);
            }

            @Override
            public int getCount() {
                // TODO Auto-generated method stub
                return list.size();
            }
        });

    }

}
