package com.example.bean;

import java.io.Serializable;

//学生加入课程实体类
public class Jiaru implements Serializable {
    int jid;
    int uid;//加入学生id
    String cid;//课程编号
    int tid;//老师id
    Users u;
    Course p;


    public Course getP() {
        return p;
    }

    public void setP(Course p) {
        this.p = p;
    }


    public Users getU() {
        return u;
    }

    public void setU(Users u) {
        this.u = u;
    }

    public int getJid() {
        return jid;
    }

    public void setJid(int jid) {
        this.jid = jid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public Jiaru(int jid, int uid, String cid, int tid) {
        super();
        this.jid = jid;
        this.uid = uid;
        this.cid = cid;
        this.tid = tid;
    }

    public Jiaru() {
        super();
    }

}
